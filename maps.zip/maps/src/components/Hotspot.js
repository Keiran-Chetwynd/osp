// src/components/Hotspot.js
import React from 'react';
import { TouchableOpacity, StyleSheet } from 'react-native';


const Hotspot = ({ x, y, onPress }) => {
  return (
    <TouchableOpacity
      style={[styles.hotspot, { top: y, left: x }]}
      onPress={onPress}
    />
  );
};

const styles = StyleSheet.create({
  hotspot: {
    position: 'absolute',
    width: 30,
    height: 30,
    backgroundColor: 'rgba(255, 0, 0, 0.5)',
    borderRadius: 5,
    zIndex: 10,
  }
});

export default Hotspot;
