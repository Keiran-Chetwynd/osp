// App.js
import React, { useState } from 'react';
import { View, Image, Modal, Text, TouchableOpacity, StyleSheet, Button } from 'react-native';
import Hotspot from './src/components/Hotspot';

const hotspots = [
  {
    id: 1,
    x: 100,
    y: 150,
    title: 'Hotspot 1',
    image: require('./assets/info1.jpg'),
    description: 'This is hotspot 1.'
  },
  {
    id: 2,
    x: 200,
    y: 250,
    title: 'Hotspot 2',
    image: require('./assets/info2.jpg'),
    description: 'This is hotspot 2.'
  }
];

export default function App() {
  const [selectedHotspot, setSelectedHotspot] = useState(null);

  return (
    <View style={styles.container}>
      <Image source={require('./assets/site_map.png')} style={styles.map} />

      {hotspots.map((hotspot) => (
        <TouchableOpacity
          key={hotspot.id}
          style={[styles.hotspot, { top: hotspot.y, left: hotspot.x }]}
          onPress={() => setSelectedHotspot(hotspot)}
        />
      ))}

      {selectedHotspot && (
        <Modal transparent={true} animationType="fade" visible={true}>
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Image source={selectedHotspot.image} style={styles.popupImage} />
              <Text style={styles.popupText}>{selectedHotspot.description}</Text>
              <Button title="Close" onPress={() => setSelectedHotspot(null)} />
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  map: { width: '100%', height: '100%', position: 'absolute' },
  hotspot: {
    position: 'absolute',
    width: 30,
    height: 30,
    backgroundColor: 'rgba(255,0,0,0.5)',
    borderRadius: 5
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.6)'
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center'
  },
  popupImage: {
    width: 200,
    height: 120,
    marginBottom: 10
  },
  popupText: {
    fontSize: 16,
    marginBottom: 10
  }
});
