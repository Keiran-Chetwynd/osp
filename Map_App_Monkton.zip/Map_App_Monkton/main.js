const androidjs = require('androidjs');
const fs = require('fs');
const path = require('path');

// Initialize Android JS
androidjs.init();

// Handle map click events
androidjs.signal.on('mapClick', (coordinates) => {
    // Handle map click coordinates
    console.log('Map clicked at:', coordinates);

    // Show a native Android toast notification
    androidjs.toast.show('Map clicked at: ' + coordinates.x + ',' + coordinates.y, 'short');
});

// Handle button click events
androidjs.signal.on('buttonClick', (buttonId) => {
    switch(buttonId) {
        case 'infoButton':
            androidjs.dialog({
                title: 'Information',
                message: 'This is your information popup',
                positive: 'OK',
                negative: 'Cancel'
            });
            break;
        case 'locationButton':
            androidjs.dialog({
                title: 'Location',
                message: 'This is your location popup',
                positive: 'OK',
                negative: 'Cancel'
            });
            break;
    }
});

// Start the app
androidjs.start();