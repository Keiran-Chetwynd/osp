// Handle map clicks
document.getElementById('map-image').addEventListener('click', (e) => {
    const rect = e.target.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Send coordinates to the backend
    androidjs.signal.emit('mapClick', {
        x: x,
        y: y
    });
});

// Button click handlers
function showInfoPopup() {
    androidjs.signal.emit('buttonClick', 'infoButton');
}

function showLocationPopup() {
    androidjs.signal.emit('buttonClick', 'locationButton');
}

// Initialize Android JS
androidjs.init();