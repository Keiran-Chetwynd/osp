// androidjs.js
class AndroidJS {
    constructor() {
        // Initialize the Android JS bridge
        this._initBridge();

        // Set up signal handlers
        this._setupSignalHandlers();

        // Initialize Node.js runtime
        this._initNodeRuntime();
    }

    _initBridge() {
        // Create the communication bridge between WebView and native code
        this.bridge = new AndroidJSBridge();

        // Expose Android JS API to window object
        window.androidjs = this;
    }

    _setupSignalHandlers() {
        // Initialize signal system for frontend-backend communication
        this.signal = new SignalSystem();

        // Handle incoming signals from frontend
        this.signal.on('ready', () => {
            this.emit('androidjsReady');
        });
    }

    _initNodeRuntime() {
        // Initialize Node.js environment
        this.node = new NodeRuntime();

        // Make npm packages available
        this.node.require = (packageName) => {
            return this._loadNpmPackage(packageName);
        };
    }

    // Signal handling methods
    signalEmit(event, data) {
        this.signal.emit(event, data);
    }

    signalOn(event, callback) {
        this.signal.on(event, callback);
    }

    // Native functionality methods
    toastShow(message, duration = 'short') {
        this.bridge.callNative('toast.show', message, duration);
    }

    dialogShow(options) {
        this.bridge.callNative('dialog.show', options);
    }

    // Node.js runtime methods
    require(packageName) {
        return this.node.require(packageName);
    }

    // Utility methods
    init() {
        this.bridge.init();
        this.emit('initialized');
    }
}

// Create the AndroidJS instance
const androidjs = new AndroidJS();

// Export the AndroidJS instance
export default androidjs;