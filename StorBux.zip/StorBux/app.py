from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import hashlib

app = Flask(__name__)


# Database connection function
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn


# Database initialization function
def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Create customers table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')

    # Create orders table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product TEXT NOT NULL,
            description TEXT,
            price FLOAT NOT NULL
        )
    ''')

    conn.commit()
    conn.close()


# Initialize database when application starts
with app.app_context():
    init_db()


@app.route('/')
def index():
    return render_template('base.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = hashlib.sha256(request.form['password'].encode()).hexdigest()

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            'SELECT * FROM customers WHERE email = ? AND password = ?',
            (email, password)
        )
        customer = cursor.fetchone()
        conn.close()

        if customer:
            # In production, use Flask session
            return redirect(url_for('products'))

    return render_template('login.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = hashlib.sha256(request.form['password'].encode()).hexdigest()

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            'INSERT INTO customers (name, email, password) VALUES (?, ?, ?)',
            (name, email, password)
        )
        conn.commit()
        conn.close()

        return redirect(url_for('login'))

    return render_template('signup.html')


@app.route('/products')
def products():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM orders')
    products_list = cursor.fetchall()
    conn.close()

    return render_template('products.html', products=products_list)


@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        product = request.form['product']
        description = request.form['description']
        price = float(request.form['price'])

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            'INSERT INTO orders (product, description, price) VALUES (?, ?, ?)',
            (product, description, price)
        )
        conn.commit()
        conn.close()

        return redirect(url_for('products'))

    return render_template('add_product.html')


if __name__ == '__main__':
    app.run(debug=True)